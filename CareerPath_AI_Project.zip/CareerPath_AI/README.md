# CareerPath AI — AI Career Roadmap & Skill Gap Finder

A Streamlit application for Problem Statement 4 in the Generative AI assignment.

## Features
- Takes the student's current skills, target job role, and available weekly study hours.
- Uses the Google Gemini API to analyze current skills and missing skills.
- Generates an 8-week learning roadmap.
- Suggests 3 mini-projects for a portfolio.
- Displays the result in a modern dashboard and lets the user download the roadmap as JSON.

## Tech stack
- Python
- Streamlit
- Google Gen AI Python SDK (`google-genai`)
- Gemini API
- Pandas

## 1. Requirements
Install Python 3.10 or later. Open this folder in VS Code.

## 2. Create a virtual environment (recommended)
Windows PowerShell:
```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt:
```bat
.venv\Scripts\activate.bat
```

## 3. Install packages
```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 4. Add your Gemini API key
Get a key from Google AI Studio: https://aistudio.google.com/

Copy `.env.example`, rename the copy to `.env`, then replace the placeholder:
```env
GEMINI_API_KEY=your_actual_key
GEMINI_MODEL=gemini-3.8-flash
```
Do not share the key, include it in screenshots, or upload `.env` to GitHub / your assignment ZIP.

If the default model is unavailable to your API account, change `GEMINI_MODEL` in `.env` and the model field in the sidebar to a model available in your AI Studio account.

## 5. Run the app
```bash
streamlit run app.py
```
The app should open in your browser. Enter your current skills, target role, and study hours, then click **Generate my AI roadmap**.

## Project structure
```text
CareerPath_AI/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
└── README.md
```

## How it works
1. Streamlit collects the student's input.
2. The Python code sends the input to Gemini using the Google Gen AI SDK.
3. Gemini returns structured JSON containing skill analysis, an 8-week roadmap, and 3 portfolio projects.
4. Streamlit displays the generated result in tabs and provides a JSON download.

## Assignment alignment
- Current skills + target role + weekly study hours: input.
- Existing skills vs. skills to learn: skill gap analysis.
- Eight-week learning roadmap: roadmap tab.
- Three mini-project ideas: portfolio projects tab.

## Important
This app gives educational suggestions, not guaranteed employment outcomes or a validated hiring score. Verify the recommended skills against current job descriptions.
