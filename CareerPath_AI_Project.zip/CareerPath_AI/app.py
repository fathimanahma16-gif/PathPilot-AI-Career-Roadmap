import json
import os
import re

import pandas as pd
import streamlit as st
from dotenv import load_dotenv
from google import genai
from google.genai import types

load_dotenv()

st.set_page_config(
    page_title="CareerPath AI | Career Roadmap",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');
:root { --ink:#eef2ff; --muted:#a8b3cf; --panel:#111a31; --line:rgba(164,180,220,.16); }
html, body, [class*="css"] { font-family:'DM Sans',sans-serif; }
.stApp { background: radial-gradient(ellipse at 12% 0%, #202b58 0%, #0b1020 42%, #080d19 100%); color:var(--ink); }
.block-container { padding-top:2rem; padding-bottom:3rem; max-width:1280px; }
h1,h2,h3 { font-family:'Space Grotesk',sans-serif !important; letter-spacing:-.035em; }
.hero { padding:1.6rem 1.8rem; border:1px solid var(--line); border-radius:22px;
        background:linear-gradient(115deg,rgba(83,105,214,.22),rgba(34,211,238,.08));
        margin-bottom:1.4rem; }
.eyebrow { color:#9caeff; font-size:.76rem; font-weight:700; letter-spacing:.16em; text-transform:uppercase; }
.hero-title { font-family:'Space Grotesk',sans-serif; font-size:2.55rem; font-weight:700; line-height:1.12; margin:.45rem 0; }
.hero-sub { color:#b7c3df; font-size:1rem; max-width:700px; }
.panel { background:rgba(17,26,49,.82); border:1px solid var(--line); border-radius:18px; padding:1.15rem 1.25rem; }
.metric { background:linear-gradient(145deg,rgba(92,111,226,.18),rgba(20,31,57,.8));
          border:1px solid var(--line); border-radius:16px; padding:1rem 1.1rem; }
.metric-label { color:#aab7d5; font-size:.8rem; }
.metric-value { font-family:'Space Grotesk'; font-size:1.8rem; font-weight:700; color:#f3f5ff; }
.week { background:rgba(19,29,53,.8); border:1px solid var(--line); border-left:3px solid #7c8cff;
        border-radius:13px; padding:1rem 1.1rem; margin:.55rem 0; }
.week small { color:#9daed3; font-weight:700; letter-spacing:.08em; }
.project-card { background:linear-gradient(145deg,rgba(33,48,86,.8),rgba(15,24,45,.9));
                border:1px solid var(--line); border-radius:16px; padding:1.1rem; height:100%; }
div[data-testid="stForm"] { background:rgba(17,26,49,.72); border:1px solid var(--line); border-radius:18px; padding:1.2rem; }
.stButton button, .stFormSubmitButton button { border-radius:12px; font-weight:700; }
[data-testid="stSidebar"] { background:#0b1224; border-right:1px solid var(--line); }
.stCaption, [data-testid="stCaptionContainer"] { color:#9eabc8 !important; }
</style>
""", unsafe_allow_html=True)

def get_api_key():
    key = os.getenv("GEMINI_API_KEY", "").strip()
    if key:
        return key
    try:
        return st.secrets.get("GEMINI_API_KEY", "").strip()
    except Exception:
        return ""

def clean_json(text):
    text = (text or "").strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
    text = re.sub(r"\s*```$", "", text)
    return json.loads(text)

def create_roadmap(api_key, model, skills, role, hours):
    client = genai.Client(api_key=api_key)
    prompt = f"""
You are a practical career mentor. Create a realistic beginner-friendly career roadmap.
Student's current skills: {skills}
Target job role: {role}
Available study time: {hours} hours per week

Return ONLY valid JSON with exactly this structure:
{{
  "career_overview": "2-3 sentence explanation of the role and path",
  "readiness_estimate": 35,
  "matched_skills": [
    {{"skill":"Skill name","level":"Current","reason":"Why it is relevant"}}
  ],
  "skills_to_learn": [
    {{"skill":"Skill name","priority":"High","reason":"Why it is needed"}}
  ],
  "roadmap": [
    {{"week":1,"focus":"Topic","tasks":["task 1","task 2"],"deliverable":"A measurable outcome"}}
  ],
  "projects": [
    {{"title":"Project title","description":"What to build","skills":["skill 1","skill 2"],"difficulty":"Beginner"}}
  ],
  "next_step": "One concrete action to start today"
}}

Rules:
- readiness_estimate must be an integer from 0 to 100 and is an approximate learning-readiness estimate, NOT a hiring or ATS score.
- Include exactly 8 roadmap weeks, numbered 1 to 8.
- Include exactly 3 portfolio project ideas.
- Include relevant current skills as matched_skills. Do not claim the student has skills they did not list.
- Make the plan fit the available weekly study hours. Be realistic and avoid promising employment.
- Use concise, actionable language. Prioritize foundational skills before advanced ones.
- Include tasks as a JSON array of short strings.
"""
    response = client.models.generate_content(
        model=model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            temperature=0.45,
            max_output_tokens=6000,
        ),
    )
    return clean_json(response.text)

# Sidebar
with st.sidebar:
    st.markdown("## 🚀 CareerPath AI")
    st.caption("Your personal AI career planner")
    st.markdown("---")
    st.markdown("**AI configuration**")
    api_key_input = st.text_input(
        "Gemini API key",
        type="password",
        value="",
        help="Optional if GEMINI_API_KEY is already set in your .env file.",
    )
    model = st.text_input("Gemini model", value=os.getenv("GEMINI_MODEL", "gemini-3.8-flash"))
    st.markdown("---")
    st.caption("Built with Python · Streamlit · Gemini")
    st.caption("Your API key is used only to make the request and is not displayed in the app.")

# Header
st.markdown("""
<div class="hero">
  <div class="eyebrow">AI CAREER INTELLIGENCE · PERSONALIZED LEARNING</div>
  <div class="hero-title">Build your next move.</div>
  <div class="hero-sub">Discover your skill gaps, get a focused 8-week learning roadmap,
  and turn your career goal into portfolio-ready projects.</div>
</div>
""", unsafe_allow_html=True)

left, right = st.columns([1.2, 0.8], gap="large")
with left:
    st.markdown("### 🎯 Define your career direction")
    with st.form("career_form"):
        skills_text = st.text_area(
            "Your current skills",
            value="Python basics, C++, HTML, CSS, JavaScript",
            height=105,
            placeholder="Example: Python, SQL, communication, Excel",
            help="Separate skills with commas. Only list skills you actually know.",
        )
        role = st.text_input(
            "Target job role",
            value="AI / Machine Learning Engineer",
            placeholder="Example: Data Analyst, Web Developer",
        )
        hours = st.slider("Study hours available per week", 2, 30, 10)
        submitted = st.form_submit_button("✨ Generate my AI roadmap", type="primary", width="stretch")
with right:
    st.markdown("### ✦ Your journey")
    st.markdown("""
    <div class="panel">
      <p style="color:#aab8da;margin:0 0 .8rem">A clear plan, one step at a time.</p>
      <div style="font-size:1.05rem;font-weight:700">01 &nbsp; Understand your strengths</div>
      <p style="color:#9eabc8;margin:.25rem 0 1rem">Map the skills you already bring.</p>
      <div style="font-size:1.05rem;font-weight:700">02 &nbsp; Find the skill gaps</div>
      <p style="color:#9eabc8;margin:.25rem 0 1rem">Prioritize what matters for your target role.</p>
      <div style="font-size:1.05rem;font-weight:700">03 &nbsp; Follow your 8-week plan</div>
      <p style="color:#9eabc8;margin:.25rem 0 1rem">Turn learning into weekly deliverables.</p>
      <div style="font-size:1.05rem;font-weight:700">04 &nbsp; Build your portfolio</div>
      <p style="color:#9eabc8;margin:.25rem 0 0">Show your progress through practical projects.</p>
    </div>
    """, unsafe_allow_html=True)

if submitted:
    skills = [s.strip() for s in skills_text.split(",") if s.strip()]
    key = api_key_input.strip() or get_api_key()
    if not skills:
        st.error("Please enter at least one current skill.")
    elif not role.strip():
        st.error("Please enter a target job role.")
    elif not key:
        st.error("Add your Gemini API key in the sidebar, or save it as GEMINI_API_KEY in your .env file.")
    else:
        with st.spinner("Gemini is analyzing your skills and designing your roadmap..."):
            try:
                result = create_roadmap(key, model.strip(), ", ".join(skills), role.strip(), hours)
                if len(result.get("roadmap", [])) != 8 or len(result.get("projects", [])) != 3:
                    st.warning("The AI response did not contain exactly 8 weeks and 3 projects. Review the generated sections carefully.")
                st.session_state["career_result"] = result
                st.session_state["career_role"] = role.strip()
                st.session_state["career_skills"] = skills
                st.success("Your personalized roadmap is ready!")
            except json.JSONDecodeError:
                st.error("Gemini returned an unreadable response. Please try again.")
            except Exception as exc:
                st.error(f"Could not generate the roadmap: {exc}")
                st.info("Check your API key, model name, internet connection and Gemini API access.")

if "career_result" in st.session_state:
    data = st.session_state["career_result"]
    st.markdown("---")
    st.markdown(f"## ✨ Your roadmap for {st.session_state['career_role']}")
    st.write(data.get("career_overview", ""))
    m1, m2, m3 = st.columns(3)
    with m1:
        st.markdown(f'<div class="metric"><div class="metric-label">Readiness estimate</div><div class="metric-value">{data.get("readiness_estimate", "—")}%</div><div class="metric-label">Approximate learning estimate</div></div>', unsafe_allow_html=True)
    with m2:
        st.markdown(f'<div class="metric"><div class="metric-label">Learning timeline</div><div class="metric-value">8 weeks</div><div class="metric-label">Structured weekly plan</div></div>', unsafe_allow_html=True)
    with m3:
        st.markdown(f'<div class="metric"><div class="metric-label">Portfolio projects</div><div class="metric-value">{len(data.get("projects", []))}</div><div class="metric-label">Ideas to demonstrate skills</div></div>', unsafe_allow_html=True)
    st.caption("The readiness estimate is an AI-generated learning estimate, not a validated hiring probability or professional assessment.")

    tab1, tab2, tab3 = st.tabs(["🧩 Skill gap analysis", "🗓️ 8-week roadmap", "💡 Portfolio projects"])
    with tab1:
        c1, c2 = st.columns(2)
        with c1:
            st.markdown("### ✅ Skills you have")
            matched = data.get("matched_skills", [])
            if matched:
                st.dataframe(pd.DataFrame(matched), hide_index=True, width="stretch")
            else:
                st.info("No matching skills were returned.")
        with c2:
            st.markdown("### 🎯 Skills to learn")
            gaps = data.get("skills_to_learn", [])
            if gaps:
                st.dataframe(pd.DataFrame(gaps), hide_index=True, width="stretch")
            else:
                st.info("No skill gaps were returned.")
    with tab2:
        for item in data.get("roadmap", []):
            tasks = item.get("tasks", [])
            task_html = "".join(f"<li>{t}</li>" for t in tasks)
            st.markdown(
                f"""<div class="week">
                <small>WEEK {item.get('week', '')}</small>
                <h3 style="margin:.3rem 0;color:#eef2ff">{item.get('focus', 'Learning focus')}</h3>
                <ul style="color:#c0cbe3;margin:.4rem 0">{task_html}</ul>
                <div style="color:#9eafff"><b>Deliverable:</b> {item.get('deliverable', '')}</div>
                </div>""",
                unsafe_allow_html=True,
            )
    with tab3:
        projects = data.get("projects", [])
        cols = st.columns(3)
        for i, project in enumerate(projects):
            with cols[i % 3]:
                skills_list = ", ".join(project.get("skills", []))
                st.markdown(
                    f"""<div class="project-card">
                    <div style="color:#9eafff;font-size:.75rem;font-weight:700">PROJECT {i+1} · {project.get('difficulty','')}</div>
                    <h3 style="color:#f0f3ff;margin:.55rem 0">{project.get('title','Project')}</h3>
                    <p style="color:#b5c2df">{project.get('description','')}</p>
                    <p style="color:#91a3d4;font-size:.83rem"><b>Skills:</b> {skills_list}</p>
                    </div>""",
                    unsafe_allow_html=True,
                )
    st.markdown("### 🚀 Your next step")
    st.info(data.get("next_step", "Choose one skill and begin practicing today."))
    export_text = json.dumps(data, indent=2, ensure_ascii=False)
    st.download_button(
        "⬇️ Download my career roadmap (JSON)",
        data=export_text,
        file_name="careerpath_ai_roadmap.json",
        mime="application/json",
    )

st.markdown("---")
st.caption("CareerPath AI is an educational planning assistant. Its suggestions are AI-generated and should be checked against current job requirements.")
